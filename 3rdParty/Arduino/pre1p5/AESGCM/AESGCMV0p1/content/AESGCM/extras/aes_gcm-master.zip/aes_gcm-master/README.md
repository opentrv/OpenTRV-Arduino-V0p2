This is a clobbered version of "wpa_supplicant and hostapd" including only
the aes-gcm implementation, distributed under the same terms as their license.
It has been modified slightly to work on AVR systems also (tested on Arduino
Uno). In theory it works on other AVRs too, however, the lookup tables are quite
memory hungry so check your flash memory constraints.

See http://w1.fi/ for the original project.
