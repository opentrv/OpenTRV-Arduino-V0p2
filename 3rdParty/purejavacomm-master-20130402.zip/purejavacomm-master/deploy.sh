#!/bin/bash
mvn deploy -Duser.name=sparetimelabs.com