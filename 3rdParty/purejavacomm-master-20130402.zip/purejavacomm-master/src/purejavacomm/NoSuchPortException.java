package purejavacomm;

public class NoSuchPortException extends Exception {

}
