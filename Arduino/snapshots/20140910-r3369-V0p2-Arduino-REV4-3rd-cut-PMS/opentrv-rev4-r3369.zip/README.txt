REV 4 is RFM23B and phototransistor and SHT21 temp_RH sensor.









Using ATmega pinout for Eagle from:
http://www.faludi.com/2008/10/07/arduino-avr-library-for-eagle-layout-editor/
without explicit licence but following email permission:

    From: Rob Faludi
    Date: 13 May 2013 00:34:52 GMT+01:00
    Subject: Re: A comment from Damon Hart-Davis

    Sure, go for it!

    A new submission (form: "Contact Form")
    ============================================
    Submitted on: May 12, 2013
    Via: /contact/

    --------------------------Contact Me----------------------

    Your Name:                      Damon Hart-Davis

    Message:
    May we use your Eagle ATmega package/library:

    http://www.faludi.com/2008/10/07/arduino-avr-library-for-eagle-layout-editor/

    In our Apache/Solderpad-licenced OpenTRV project please?

    Rgds

    Damon
    http://opentrv.org.uk/



Note ITEADstudio .dru and .cam files downloaded from their site AND NOT COVERED BY OUR APACHE LICENCE
though ITEADstudio would probably be happy for you to use their service like we did!




Component-ordering document: https://docs.google.com/spreadsheet/ccc?key=0AkWwv0Q6wTaZdFh3cEtPVEh3Qzg0OFE3LVdkSHd2amc#gid=0