RPi Relay board w/ Whip Antenna Mod.

- BOM and assembly notes are in `manufacturing/`
- Gerbers are in `manufacturing/gerber/`

